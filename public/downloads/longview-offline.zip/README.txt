Longview offline demo

Unzip this folder. With Python 3 installed, run:
  python3 run-offline.py
Then open the local URL printed by the script on that computer (usually http://127.0.0.1:8000). A free port is selected if 8000 is occupied. No internet is required for the model or bundled data. Original-source links require internet.

This is a research prototype, not a clinical or causal model. Human policy review is pending in this release. The 90% evidence-verification target is not yet measured. See Data & method in the app for country failures and data limitations.

Slides and the video are separate downloads on the hosted app. The private reviewer packet is excluded from this offline copy.
