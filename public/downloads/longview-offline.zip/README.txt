Longview funding report — release 5377161e107b0f80

Unzip, then with Python 3 run:
  python3 run-offline.py
Open the address printed by the server on that computer. The public funding report and source ledger need no internet. Original-source links require internet.

Human verification: 0/60 reviewed. The numerical estimates remain pending until all human review requirements pass. No private reviewer packet is included. This is a research-funding communication prototype, not a national ranking or clinical tool.
